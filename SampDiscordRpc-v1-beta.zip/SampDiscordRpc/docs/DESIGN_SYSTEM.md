# HEXED design system (SampDiscordRpc 1.3)

Derived from the official logo (`apk_logo.png`): a chrome-silver "H" monogram with sparkle accents on liquid
cobalt-blue marble. Personality: futuristic, metallic, electric, premium-dark.
Measured from the logo: ~35% deep blue (#0F115F), ~24% cobalt (#232BAE), ~15% bright blue (#6F7BF0),
~16% chrome/white (#D2D1DC), ~8% near-black (#03031A); most vivid hue #0F21F8.

## Colors (`res/values/colors.xml`)
| Token | Hex | Use |
|---|---|---|
| hx_bg_deep / hx_bg_top | #04061A / #0B1259 | screen background gradient (top to bottom), nav bar / status bar |
| hx_surface | #0C1250 | cards |
| hx_surface_raised | #141D78 | disabled controls |
| hx_border / hx_divider | #2B3AA8 / #26307F | card border / row dividers |
| hx_brand_start / hx_brand / hx_brand_dark / hx_brand_pressed | #3148FF / #1B2FF0 / #1020D8 / #0A14A8 | primary button gradient, pressed state, notification accent |
| hx_brand_light | #8C9EFF | section labels, outline buttons, listening state |
| hx_chrome | #E4E9F7 | logo ring, focus ring, outline-button text |
| hx_text / hx_text_muted / hx_text_disabled | #F4F6FF / #A9B4E6 / #6B76B0 | primary / secondary / disabled text |
| hx_success / hx_warning / hx_error | #4EE0B0 / #FFC266 / #FF8CA0 | status dots and text |

Contrast (WCAG, computed): text on surface 16.0:1, muted on surface 8.5:1, muted on background 9.9:1,
white on primary-button gradient 6.0:1 to 9.5:1, labels 6.9:1, error 7.8:1, success 10.4:1, warning 10.8:1.
Status is never conveyed by color alone: every dot sits next to text.

## Typography (system fonts, no bundled files)
| Role | Style |
|---|---|
| Screen title | sans-serif-medium bold, 26sp |
| Section label | sans-serif-medium, 12sp, uppercase, letter-spacing 0.16, brand_light |
| Overline (studio / version) | sans-serif-medium, 12sp, uppercase, letter-spacing 0.18, muted |
| Status value | sans-serif-medium, 17sp |
| Body / row label | sans-serif, 14sp |
| Caption | sans-serif, 13sp, muted |
| Button | sans-serif-medium, 16sp, no all-caps |
| Crash trace | monospace, 11sp |

## Shape, spacing, size
Card radius 22dp, button radius 16dp, logo radius 26dp (+2dp chrome ring), card padding 18dp, section gap 22dp,
button gap 12dp, button min height 52dp, content column max width 560dp (centered on tablets / landscape),
screen padding 20dp. All sizes are dp (no device-specific pixels).

## Components (`Ui.kt`)
- **card()**: surface + 1dp border. **divider()**, **infoRow()** (label, status dot, value).
- **button(kind)**: PRIMARY (cobalt gradient, white text), OUTLINE (brand_light stroke), DANGER (error stroke), GHOST (text only).
  States: normal, pressed (darker + ripple), focused (2dp chrome ring), disabled (muted). A loading state is not needed: no button runs an async action in the UI.
- **dot()**, **text() / screenTitle() / sectionLabel() / caption()**.
- **reveal()**: 260ms fade + 14dp slide, 60ms stagger, only on first launch; follows the system animation scale.

## Logo assets
| Asset | Path |
|---|---|
| In-app / splash artwork (512px, unmodified) | `res/drawable-nodpi/hexed_logo.png` |
| Adaptive icon (logo as background layer, inset 14dp so the whole mark stays in the safe zone) | `res/mipmap-anydpi-v26/ic_launcher*.xml`, `drawable/ic_launcher_background.xml` |
| Legacy icons 48 to 192px (rounded square + round) | `res/mipmap-*/ic_launcher*.png` |
| Launch screen (pre-Android 12) | `res/drawable/bg_launch.xml` |
| Android 12+ splash | `res/values-v31/themes.xml` (brand background + launcher icon) |
| Status-bar glyph (four-point sparkle from the logo; status icons must be flat white) | `res/drawable/ic_stat_hexed.xml` |
| 512px store icon | `docs/assets/ic_launcher_512.png` |

The logo is opaque (no transparency), so it can't be cut out of its background. It is used only as supplied,
scaled uniformly, never recolored, stretched or redrawn.
