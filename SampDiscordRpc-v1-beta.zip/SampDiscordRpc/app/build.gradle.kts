plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val discordAppId: String = (System.getenv("DISCORD_APP_ID") ?: "")
    .filter { it.isDigit() }
    .ifEmpty { "1566671569479147600" }

android {
    namespace = "com.hexed.sampdiscordrpc"
    compileSdk = 34
    ndkVersion = "27.0.12077973"

    defaultConfig {
        applicationId = "com.hexed.sampdiscordrpc"
        minSdk = 24
        targetSdk = 34
        versionCode = 5
        versionName = "1.2"

        buildConfigField("long", "DISCORD_APP_ID", "${discordAppId}L")
        manifestPlaceholders["discordAppId"] = discordAppId

        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
        externalNativeBuild {
            cmake {
                arguments += listOf("-DANDROID_STL=c++_shared")
                cppFlags += "-std=c++20"
            }
        }
    }

    buildFeatures {
        prefab = true
        buildConfig = true
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }

    packaging {
        jniLibs {
            pickFirsts += "**/libc++_shared.so"
        }
    }
}

dependencies {
    implementation(files("libs/discord_partner_sdk.aar"))
    implementation("androidx.browser:browser:1.8.0")
    // the SDK's AuthenticationActivity / ForegroundService use WindowInsetsControllerCompat (core >= 1.5)
    // and NotificationCompat; the AAR is a plain file so its dependencies are NOT pulled in automatically
    implementation("androidx.core:core-ktx:1.13.1")
}
