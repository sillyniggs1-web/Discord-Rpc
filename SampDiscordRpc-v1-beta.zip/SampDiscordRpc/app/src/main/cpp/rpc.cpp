// SampDiscordRpc native core
// UDP listener (127.0.0.1:<port>) + Discord Social SDK rich presence, one worker thread.

#define DISCORDPP_IMPLEMENTATION // exactly one file
#include "discordpp.h"

#include <jni.h>
#include <android/log.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>

#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#define TAG "SampDiscordRpc"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

namespace {

std::atomic<bool> g_run{false};
std::thread g_thread;
std::mutex g_mu;
std::string g_status = "Stopped";

void setStatus(const std::string& s) {
    std::lock_guard<std::mutex> lock(g_mu);
    g_status = s;
}

struct State {
    bool active = false;
    std::string nick, server, ip;
    int port = 7777;
    int players = 0;
    long long start = 0;
};

std::vector<std::string> split(const std::string& s, char sep) {
    std::vector<std::string> out;
    std::string cur;
    for (char c : s) {
        if (c == sep) { out.push_back(cur); cur.clear(); }
        else cur.push_back(c);
    }
    out.push_back(cur);
    return out;
}

// cut to at most `max` bytes without splitting a UTF-8 character
std::string clip(const std::string& s, size_t max) {
    if (s.size() <= max) return s;
    size_t n = max;
    while (n > 0 && (static_cast<unsigned char>(s[n]) & 0xC0) == 0x80) --n;
    return s.substr(0, n);
}

// HXRPC1 \t STATE \t nick \t id \t server \t ip \t port \t players \t startEpoch
// HXRPC1 \t BYE
bool parse(const std::string& msg, State& out, bool& bye) {
    auto f = split(msg, '\t');
    if (f.size() < 2 || f[0] != "HXRPC1") return false;
    if (f[1] == "BYE") { bye = true; return true; }
    if (f[1] != "STATE" || f.size() < 9) return false;
    bye = false;
    out.active = true;
    out.nick = f[2];
    out.server = f[4];
    out.ip = f[5];
    out.port = std::atoi(f[6].c_str());
    out.players = std::atoi(f[7].c_str());
    out.start = std::atoll(f[8].c_str());
    return true;
}

void push(const std::shared_ptr<discordpp::Client>& client, const State& s) {
    if (!s.active) {
        client->ClearRichPresence();
        setStatus("Presence cleared (not in a server)");
        return;
    }
    std::string details = s.server.empty() ? std::string("SA-MP server") : s.server;
    std::string who = s.nick.empty() ? std::string("player") : s.nick;
    std::string state = who + " \xE2\x80\xA2 " + s.ip + ":" + std::to_string(s.port);

    discordpp::Activity a;
    a.SetType(discordpp::ActivityTypes::Playing);
    a.SetName("San Andreas Multiplayer");
    a.SetDetails(clip(details, 120));
    a.SetState(clip(state, 120));
    if (s.start > 0) {
        discordpp::ActivityTimestamps ts;
        ts.SetStart(static_cast<uint64_t>(s.start)); // unix seconds, counts up as "elapsed"
        a.SetTimestamps(ts);
    }

    client->UpdateRichPresence(a, [](discordpp::ClientResult r) {
        if (r.Successful()) setStatus("Presence active");
        else setStatus("Presence failed: " + std::string(r.Error()));
    });
}

void worker(uint64_t appId, int port) {
    using clock = std::chrono::steady_clock;
    using std::chrono::seconds;

    auto client = std::make_shared<discordpp::Client>();
    client->AddLogCallback([](auto message, auto severity) {
        LOGI("[sdk] %s", std::string(message).c_str());
    }, discordpp::LoggingSeverity::Info);

    // Rich presence through the local Discord app: no OAuth, no Connect().
    client->SetApplicationId(appId);

    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) {
        setStatus("socket() failed");
        g_run = false;
        return;
    }
    int one = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(static_cast<uint16_t>(port));
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    if (bind(fd, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) < 0) {
        setStatus("bind to 127.0.0.1:" + std::to_string(port) + " failed");
        close(fd);
        g_run = false;
        return;
    }
    timeval tv{0, 100000}; // 100 ms, so RunCallbacks keeps ticking
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    setStatus("Waiting for game data on 127.0.0.1:" + std::to_string(port));

    State cur;
    std::string lastKey;
    auto lastPush = clock::time_point{};
    auto lastPacket = clock::now();
    char buf[2048];

    while (g_run) {
        ssize_t n = recvfrom(fd, buf, sizeof(buf) - 1, 0, nullptr, nullptr);
        auto now = clock::now();
        if (n > 0) {
            State st;
            bool bye = false;
            if (parse(std::string(buf, static_cast<size_t>(n)), st, bye)) {
                lastPacket = now;
                cur = bye ? State{} : st;
            }
        }
        // the game script stopped sending: treat it as "left the server"
        if (cur.active && now - lastPacket > seconds(10)) cur = State{};

        std::string key = cur.active
            ? cur.server + "|" + cur.ip + ":" + std::to_string(cur.port) + "|" + cur.nick + "|" + std::to_string(cur.start)
            : std::string();
        if (key != lastKey || (cur.active && now - lastPush > seconds(30))) {
            push(client, cur);
            lastKey = key;
            lastPush = now;
        }
        discordpp::RunCallbacks();
    }

    client->ClearRichPresence();
    for (int i = 0; i < 5; ++i) {
        discordpp::RunCallbacks();
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
    close(fd);
}

} // namespace

extern "C" {

JNIEXPORT void JNICALL Java_com_hexed_sampdiscordrpc_Native_start(JNIEnv*, jclass, jlong appId, jint port) {
    if (g_run.exchange(true)) return;
    if (g_thread.joinable()) g_thread.join();
    g_thread = std::thread(worker, static_cast<uint64_t>(appId), static_cast<int>(port));
}

JNIEXPORT void JNICALL Java_com_hexed_sampdiscordrpc_Native_stop(JNIEnv*, jclass) {
    g_run = false;
    if (g_thread.joinable()) g_thread.join();
    setStatus("Stopped");
}

JNIEXPORT jstring JNICALL Java_com_hexed_sampdiscordrpc_Native_status(JNIEnv* env, jclass) {
    std::lock_guard<std::mutex> lock(g_mu);
    return env->NewStringUTF(g_status.c_str());
}

} // extern "C"
