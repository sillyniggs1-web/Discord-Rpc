package com.hexed.sampdiscordrpc

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

class RpcService : Service() {

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            // only an explicit Stop turns the service off for good (no restart after reboot / kill)
            Prefs.setEnabled(this, false)
            Native.stop()
            releaseWakeLock()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        Prefs.setEnabled(this, true)
        startInForeground()
        acquireWakeLock()
        Native.start(BuildConfig.DISCORD_APP_ID, PORT, filesDir.absolutePath)
        return START_STICKY   // the system restarts the service if it gets killed
    }

    override fun onDestroy() {
        Native.stop()
        releaseWakeLock()
        super.onDestroy()
    }

    /** Keeps the CPU awake so the UDP listener and the Discord connection never stall in doze. */
    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        runCatching {
            val pm = getSystemService(PowerManager::class.java)
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sampdiscordrpc:service").apply {
                setReferenceCounted(false)
                acquire()
            }
        }
    }

    private fun releaseWakeLock() {
        runCatching { if (wakeLock?.isHeld == true) wakeLock?.release() }
        wakeLock = null
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        val builder: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Discord RPC", NotificationManager.IMPORTANCE_LOW)
            )
            builder = Notification.Builder(this, CHANNEL)
        } else {
            @Suppress("DEPRECATION")
            builder = Notification.Builder(this)
        }
        val n = builder
            .setContentTitle("SA-MP Discord RPC")
            .setContentText("Running in the background (port $PORT)")
            .setSmallIcon(R.drawable.ic_stat_hexed)
            .setColor(getColor(R.color.hx_brand))
            .setContentIntent(
                PendingIntent.getActivity(
                    this, 0, Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    companion object {
        const val ACTION_STOP = "com.hexed.sampdiscordrpc.STOP"
        const val PORT = 6464
        private const val CHANNEL = "rpc"
        private const val NOTIF_ID = 1
    }
}
