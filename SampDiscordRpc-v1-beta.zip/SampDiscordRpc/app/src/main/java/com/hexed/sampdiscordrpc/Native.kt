package com.hexed.sampdiscordrpc

object Native {
    init {
        System.loadLibrary("sampdiscordrpc")
    }

    @JvmStatic external fun start(appId: Long, port: Int)
    @JvmStatic external fun stop()
    @JvmStatic external fun status(): String
}
