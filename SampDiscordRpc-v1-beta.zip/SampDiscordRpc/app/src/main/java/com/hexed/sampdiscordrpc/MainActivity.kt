package com.hexed.sampdiscordrpc

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    private enum class Tone { OK, LISTEN, WAIT, BAD, IDLE }

    private lateinit var ui: Ui
    private lateinit var statusDot: View
    private lateinit var statusText: TextView
    private lateinit var loginRow: Ui.InfoRow
    private lateinit var batteryRow: Ui.InfoRow
    private lateinit var logoutButton: Button
    private var lastStatus = ""

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            refreshStatus()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // remember the last Java crash (also from the SDK's login activity) and show it on next start
        val crashFile = File(filesDir, "last_crash.txt")
        val lastCrash = runCatching { if (crashFile.exists()) crashFile.readText() else null }.getOrNull()
        runCatching { crashFile.delete() }
        val prevHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching { crashFile.writeText(android.util.Log.getStackTraceString(e)) }
            prevHandler?.uncaughtException(t, e)
        }

        // required by the Social SDK on Android
        com.discord.socialsdk.DiscordSocialSdkInit.setEngineActivity(this)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        ui = Ui(this)
        setContentView(buildContent(lastCrash, savedInstanceState == null))
    }

    // ------------------------------------------------------------------ screen

    private fun buildContent(lastCrash: String?, animate: Boolean): View {
        val root = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(ui.c(R.color.hx_bg_top), ui.c(R.color.hx_bg_deep))
            )
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
        }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(20), ui.dp(28), ui.dp(20), ui.dp(28))
        }
        scroll.addView(column, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // wide screens (tablets, landscape): keep one centred column of at most 560dp
        scroll.addOnLayoutChangeListener { _, l, _, r, _, _, _, _, _ ->
            val side = maxOf(ui.dp(20), ((r - l) - ui.dp(560)) / 2)
            if (column.paddingLeft != side) {
                column.post { column.setPadding(side, ui.dp(28), side, ui.dp(28)) }
            }
        }

        val blocks = ArrayList<View>()

        // ---- header: logo, title, version
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        header.addView(buildLogo(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = ui.dp(18)
            topMargin = ui.dp(6)
        })
        header.addView(ui.screenTitle("SA-MP Discord RPC"), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        header.addView(ui.overline("HEXED Studio  \u2022  v" + BuildConfig.VERSION_NAME), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = ui.dp(6)
        })
        val hint = if (BuildConfig.DISCORD_APP_ID == 0L)
            "Discord application ID is not set. Set the DISCORD_APP_ID variable and rebuild."
        else
            "Discord must be installed and signed in on this phone. " +
                "Tap Start service (local presence), or Log in with Discord for the full login."
        header.addView(ui.caption(hint).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = ui.dp(14)
        })
        column.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        blocks.add(header)

        // ---- connection status
        statusDot = ui.dot(10, ui.c(R.color.hx_text_disabled)).apply {
            (layoutParams as LinearLayout.LayoutParams).rightMargin = ui.dp(12)
        }
        statusText = ui.text("", 17f, R.color.hx_text, "sans-serif-medium").apply {
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        }
        val statusLine = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, ui.dp(12))
            addView(statusDot)
            addView(statusText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        loginRow = ui.infoRow("Saved Discord login")
        batteryRow = ui.infoRow("Background battery")
        val statusCard = ui.card().apply {
            addView(statusLine)
            addView(ui.divider())
            addView(loginRow.root)
            addView(ui.divider())
            addView(batteryRow.root)
        }
        blocks.add(section("Connection", statusCard).also { column.addView(it) })

        // ---- service
        blocks.add(section(
            "Service",
            ui.button("Start service", Ui.Kind.PRIMARY) { startRpcService() },
            ui.button("Stop service", Ui.Kind.DANGER) {
                startService(Intent(this, RpcService::class.java).setAction(RpcService.ACTION_STOP))
            }
        ).also { column.addView(it) })

        // ---- account
        logoutButton = ui.button("Log out (forget saved account)", Ui.Kind.OUTLINE) {
            File(filesDir, "discord_login.txt").delete()
            File(filesDir, "discord_login.txt.tmp").delete()
            runCatching { Native.logout() }
        }
        blocks.add(section(
            "Discord account",
            ui.button("Log in with Discord", Ui.Kind.PRIMARY) {
                startRpcService()   // the login runs inside the service's native thread
                Native.login()
            },
            logoutButton
        ).also { column.addView(it) })

        // ---- background
        blocks.add(section(
            "Background",
            ui.button("Battery settings", Ui.Kind.GHOST) { requestBatteryExemption() },
            ui.caption("Unrestricted battery lets Android keep the service running so your presence never disconnects.")
        ).also { column.addView(it) })

        // ---- last crash (only when there was one)
        if (!lastCrash.isNullOrBlank()) {
            val crashText = ui.text(lastCrash.take(1500), 11f, R.color.hx_text_muted, "monospace")
            val crashCard = ui.card().apply {
                background = GradientDrawable().apply {
                    cornerRadius = ui.dpf(Ui.RADIUS_CARD)
                    setColor(ui.c(R.color.hx_surface))
                    setStroke(ui.dp(1), ui.c(R.color.hx_error))
                }
                addView(ui.text("Last crash", 14f, R.color.hx_error, "sans-serif-medium"))
                addView(crashText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = ui.dp(8)
                })
            }
            blocks.add(crashCard.also {
                column.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = ui.dp(22)
                })
            })
        }

        refreshStatus()
        if (animate) ui.reveal(blocks)
        return root
    }

    /** Logo in a chrome ring with a soft brand-blue glow. The artwork is shown as supplied (no recolor / distortion). */
    private fun buildLogo(): View {
        val ring = FrameLayout(this).apply {
            val p = ui.dp(2)
            setPadding(p, p, p, p)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(ui.c(R.color.hx_chrome), ui.c(R.color.hx_brand_light), ui.c(R.color.hx_chrome))
            ).apply { cornerRadius = ui.dpf(28) }
            elevation = ui.dpf(10)
            if (Build.VERSION.SDK_INT >= 28) {
                outlineSpotShadowColor = ui.c(R.color.hx_brand)
                outlineAmbientShadowColor = ui.c(R.color.hx_brand)
            }
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.hexed_logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "HEXED logo"
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, ui.dpf(26))
                }
            }
            clipToOutline = true
        }
        ring.addView(logo, FrameLayout.LayoutParams(ui.dp(104), ui.dp(104)))
        return ring
    }

    /** Section label + card holding the given views (buttons get a 12dp gap). */
    private fun section(label: String, vararg content: View): LinearLayout {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = ui.dp(22) }
        }
        wrap.addView(ui.sectionLabel(label).apply { setPadding(ui.dp(4), 0, 0, ui.dp(10)) })
        val card = if (content.size == 1 && content[0] is LinearLayout && content[0].parent == null &&
            content[0].background is GradientDrawable) content[0] else null
        if (card != null) {
            wrap.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        } else {
            val box = ui.card()
            content.forEachIndexed { i, v ->
                val lp = (v.layoutParams as? LinearLayout.LayoutParams)
                    ?: LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                if (i > 0) lp.topMargin = ui.dp(12)
                v.layoutParams = lp
                box.addView(v)
            }
            wrap.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        return wrap
    }

    // ------------------------------------------------------------------ status

    private fun toneOf(st: String): Tone {
        val s = st.lowercase()
        return when {
            s.startsWith("stopped") || s.startsWith("logged out") -> Tone.IDLE
            s.contains("retrying") -> Tone.WAIT
            s.contains("failed") || s.contains("error") || s.contains("expired") ||
                s.contains("not loaded") || s.startsWith("bind to") -> Tone.BAD
            s.contains("presence active") || s.contains("logged in") -> Tone.OK
            s.startsWith("waiting for game") || s.startsWith("presence cleared") -> Tone.LISTEN
            else -> Tone.WAIT
        }
    }

    private fun toneColor(t: Tone): Int = ui.c(
        when (t) {
            Tone.OK -> R.color.hx_success
            Tone.LISTEN -> R.color.hx_brand_light
            Tone.WAIT -> R.color.hx_warning
            Tone.BAD -> R.color.hx_error
            Tone.IDLE -> R.color.hx_text_disabled
        }
    )

    private fun refreshStatus() {
        val st = runCatching { Native.status() }.getOrDefault("Native library not loaded")
        if (st != lastStatus) {   // only touch the view when it changed (keeps screen readers quiet)
            lastStatus = st
            statusText.text = st
            ui.setDot(statusDot, toneColor(toneOf(st)))
        }

        val saved = File(filesDir, "discord_login.txt").exists()
        loginRow.value.text = if (saved) "Yes" else "No"
        ui.setDot(loginRow.dot, ui.c(if (saved) R.color.hx_success else R.color.hx_text_disabled))
        logoutButton.isEnabled = saved

        val free = batteryExempt()
        batteryRow.value.text = if (free) "Unrestricted" else "Restricted"
        ui.setDot(batteryRow.dot, ui.c(if (free) R.color.hx_success else R.color.hx_warning))
    }

    // ------------------------------------------------------------------ actions

    private fun startRpcService() {
        val i = Intent(this, RpcService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    private fun batteryExempt(): Boolean =
        getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)

    /** Asks Android to never put the app to sleep, so presence stays connected in the background. */
    private fun requestBatteryExemption() {
        if (batteryExempt()) {
            Toast.makeText(this, "Already unrestricted", Toast.LENGTH_SHORT).show()
            return
        }
        runCatching {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        }.onFailure {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    override fun onResume() {
        super.onResume()
        // once, after the user turned the service on: ask for the battery exemption
        if (Prefs.enabled(this) && !Prefs.askedBattery(this) && !batteryExempt()) {
            Prefs.setAskedBattery(this)
            requestBatteryExemption()
        }
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }
}
