package com.hexed.sampdiscordrpc

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    private lateinit var statusView: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            val st = runCatching { Native.status() }.getOrDefault("Native library not loaded")
            val saved = if (File(filesDir, "discord_login.txt").exists()) "yes" else "no"
            val bat = if (batteryExempt()) "unrestricted" else "RESTRICTED (tap Battery settings)"
            statusView.text = st + "\nSaved Discord login: " + saved + "   |   Battery: " + bat
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // remember the last Java crash (also from the SDK's login activity) and show it on next start
        val crashFile = java.io.File(filesDir, "last_crash.txt")
        val lastCrash = runCatching { if (crashFile.exists()) crashFile.readText() else null }.getOrNull()
        runCatching { crashFile.delete() }
        val prevHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching { crashFile.writeText(android.util.Log.getStackTraceString(e)) }
            prevHandler?.uncaughtException(t, e)
        }

        // required by the Social SDK on Android
        com.discord.socialsdk.DiscordSocialSdkInit.setEngineActivity(this)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad * 2, pad * 3, pad * 2, pad)
        }

        fun label(text: String, size: Float) = TextView(this).apply {
            this.text = text
            textSize = size
            setPadding(0, 0, 0, pad)
        }

        fun button(text: String, onClick: () -> Unit) = Button(this).apply {
            this.text = text
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        root.addView(label("SA-MP Discord RPC", 24f))
        val hint = if (BuildConfig.DISCORD_APP_ID == 0L)
            "Discord application ID is not set. Set the DISCORD_APP_ID variable and rebuild."
        else
            "Discord must be installed and signed in on this phone. " +
                "Tap Start service (local presence), or Log in with Discord for the full login."
        root.addView(label(hint, 14f))

        statusView = label("", 16f)
        root.addView(statusView)

        if (!lastCrash.isNullOrBlank()) {
            root.addView(label("Last crash:\n" + lastCrash.take(1500), 10f))
        }

        root.addView(button("Start service") { startRpcService() })
        root.addView(button("Log in with Discord") {
            startRpcService()   // the login runs inside the service's native thread
            Native.login()
        })
        root.addView(button("Log out (forget saved account)") {
            File(filesDir, "discord_login.txt").delete()
            File(filesDir, "discord_login.txt.tmp").delete()
            runCatching { Native.logout() }
        })
        root.addView(button("Stop service") {
            startService(Intent(this, RpcService::class.java).setAction(RpcService.ACTION_STOP))
        })
        root.addView(button("Battery settings") { requestBatteryExemption() })

        setContentView(root)
    }

    private fun startRpcService() {
        val i = Intent(this, RpcService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    private fun batteryExempt(): Boolean =
        getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)

    /** Asks Android to never put the app to sleep, so presence stays connected in the background. */
    private fun requestBatteryExemption() {
        if (batteryExempt()) {
            Toast.makeText(this, "Already unrestricted", Toast.LENGTH_SHORT).show()
            return
        }
        runCatching {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        }.onFailure {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    override fun onResume() {
        super.onResume()
        // once, after the user turned the service on: ask for the battery exemption
        if (Prefs.enabled(this) && !Prefs.askedBattery(this) && !batteryExempt()) {
            Prefs.setAskedBattery(this)
            requestBatteryExemption()
        }
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }
}
