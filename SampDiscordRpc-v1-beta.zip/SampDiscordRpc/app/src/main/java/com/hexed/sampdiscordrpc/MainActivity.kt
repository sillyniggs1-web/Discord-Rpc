package com.hexed.sampdiscordrpc

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var statusView: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            statusView.text = runCatching { Native.status() }.getOrDefault("Native library not loaded")
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // required by the Social SDK on Android
        com.discord.socialsdk.DiscordSocialSdkInit.setEngineActivity(this)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad * 2, pad * 3, pad * 2, pad)
        }

        fun label(text: String, size: Float) = TextView(this).apply {
            this.text = text
            textSize = size
            setPadding(0, 0, 0, pad)
        }

        fun button(text: String, onClick: () -> Unit) = Button(this).apply {
            this.text = text
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        root.addView(label("SA-MP Discord RPC", 24f))
        val hint = if (BuildConfig.DISCORD_APP_ID == 0L)
            "Discord application ID is not set. Set the DISCORD_APP_ID variable and rebuild."
        else
            "Discord must be installed and signed in on this phone. " +
                "Tap Start service (local presence), or Log in with Discord for the full login."
        root.addView(label(hint, 14f))

        statusView = label("", 16f)
        root.addView(statusView)

        root.addView(button("Start service") { startRpcService() })
        root.addView(button("Log in with Discord") {
            startRpcService()   // the login runs inside the service's native thread
            Native.login()
        })
        root.addView(button("Stop service") {
            startService(Intent(this, RpcService::class.java).setAction(RpcService.ACTION_STOP))
        })
        root.addView(button("Battery settings") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        setContentView(root)
    }

    private fun startRpcService() {
        val i = Intent(this, RpcService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }
}
