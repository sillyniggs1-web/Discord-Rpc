# SampDiscordRpc

Companion app for `Discord_RPC_Bridge.lua` (Nezuko / MonetLoader).
Listens on UDP 127.0.0.1:6464 and sets Discord Rich Presence through the Discord Social SDK (C++).
The Social SDK AAR is already in `app/libs/` (arm64-v8a + armeabi-v7a only).
The Discord application ID is set in `app/build.gradle.kts` (env var DISCORD_APP_ID overrides it).

## Use
1. Install and sign in to Discord on the same phone.
2. Open the app, tap Start service (allow notifications, exempt it from battery optimisation).
3. Join a server in Nezuko with the bridge script running.
