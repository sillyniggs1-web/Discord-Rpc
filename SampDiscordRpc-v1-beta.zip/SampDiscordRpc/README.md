# SampDiscordRpc (v1.1.2 beta)

Companion app for `Discord_RPC_Bridge.lua` (Nezuko / MonetLoader).
Listens on UDP 127.0.0.1:6464 and sets Discord Rich Presence through the Discord Social SDK (C++).
The Social SDK AAR is already in `app/libs/` (arm64-v8a + armeabi-v7a only).
The Discord application ID is set in `app/build.gradle.kts` (env var DISCORD_APP_ID overrides it).

## 1.1.2
- Logging in now installs the app on the user's Discord account as a **user install**, so each login is counted under "Individual Users" in the developer portal.
  In the portal, open **Installation** and make sure **User Install** is enabled (and add the `applications.commands` scope if it asks for one).

## 1.1.1
- Fix: tapping **Log in with Discord** crashed the app. The SDK's login activity needs `androidx.core` (>= 1.5), which was missing from the project; it is now a declared dependency.
- The main screen shows the last Java crash stack trace on the next start, to make reports easier.

## What's new in 1.1
- **Log in with Discord** (OAuth2 + PKCE). Presence is then sent through your logged-in account instead of only the local Discord app.
- The refresh token is saved in the app's private storage (`discord_login.txt`), so you only log in once. On every start the app restores the login automatically.
- Manifest now registers the OAuth redirect `discord-<APP_ID>:/authorize/callback` (the app ID is injected from `build.gradle.kts`).

## Use
1. Install and sign in to Discord on the same phone.
2. Open the app and either:
   - tap **Start service** (local presence through the Discord app, same as 1.0), or
   - tap **Log in with Discord**, approve the request, and the service starts and connects.
   Allow notifications and exempt the app from battery optimisation.
3. Join a server in Nezuko with the bridge script running.

## Discord developer portal (needed for the login)
In your application's OAuth2 settings, add this redirect:

    discord-<YOUR_APP_ID>:/authorize/callback

and enable **Public Client**, since the app exchanges the code with PKCE and has no client secret.
If the status line says "Authorize failed" or "Token exchange failed", check these two first.
